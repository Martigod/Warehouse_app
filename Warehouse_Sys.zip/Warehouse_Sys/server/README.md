﻿# Warehouse Flow Server (Scaffold)

Node/Express + SQLite backend scaffold for multi-user sync.

## Quick Start

1. `cd server`
2. `npm install`
3. Copy `.env.example` to `.env` (optional)
4. `npm run dev`

## Endpoints

- `GET /health`
- `POST /auth/login` (demo roles: `admin/admin123`, `manager/manager123`, `operator/operator123`)
- `GET/POST/PUT/DELETE /api/products`
- `GET/POST/PUT/DELETE /api/suppliers`
- `GET/POST/PUT/DELETE /api/purchase-orders`
- `GET/POST /api/activities`

This scaffold is intentionally simple (no JWT/session persistence yet). It is meant as a clean starting point for multi-user sync and API integration.
