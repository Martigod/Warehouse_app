﻿import express from "express";
import cors from "cors";
import morgan from "morgan";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createDb } from "./db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const serverRoot = path.resolve(__dirname, "..");
const clientRoot = path.resolve(serverRoot, "..");
const PORT = Number(process.env.PORT || 3001);
const DB_FILE = process.env.DB_FILE || "./data/warehouse.db";
const CORS_ORIGIN = process.env.CORS_ORIGIN || "*";

const db = createDb(path.resolve(serverRoot, DB_FILE));
const app = express();
app.use(cors({ origin: CORS_ORIGIN === "*" ? true : CORS_ORIGIN }));
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));
app.use(express.static(clientRoot));

const DEMO_USERS = [
  { username: "admin", password: "admin123", role: "admin", displayName: "Admin" },
  { username: "manager", password: "manager123", role: "manager", displayName: "Warehouse Manager" },
  { username: "operator", password: "operator123", role: "operator", displayName: "Warehouse Operator" },
];

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "warehouse-flow-server", now: new Date().toISOString() });
});

app.get("/", (_req, res) => {
  res.sendFile(path.join(clientRoot, "login.html"));
});

app.post("/auth/login", (req, res) => {
  const { username, password } = req.body || {};
  const user = DEMO_USERS.find((u) => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ error: "Invalid credentials" });
  res.json({
    token: `demo-${user.role}-${Date.now()}`,
    user: { username: user.username, role: user.role, displayName: user.displayName },
  });
});

app.get("/api/products", (_req, res) => {
  const rows = db.prepare(`SELECT sku, name, category, supplier, zone, stock, min_stock as minStock, price, lead_time as leadTime, supplier_priority as supplierPriority, description, updated_at as updatedAt FROM products ORDER BY name COLLATE NOCASE`).all();
  res.json(rows);
});

app.post("/api/products", (req, res) => {
  const p = normalizeProductBody(req.body);
  db.prepare(`INSERT INTO products (sku, name, category, supplier, zone, stock, min_stock, price, lead_time, supplier_priority, description, updated_at)
              VALUES (@sku, @name, @category, @supplier, @zone, @stock, @minStock, @price, @leadTime, @supplierPriority, @description, @updatedAt)
              ON CONFLICT(sku) DO UPDATE SET
                name=excluded.name, category=excluded.category, supplier=excluded.supplier, zone=excluded.zone,
                stock=excluded.stock, min_stock=excluded.min_stock, price=excluded.price, lead_time=excluded.lead_time,
                supplier_priority=excluded.supplier_priority, description=excluded.description, updated_at=excluded.updated_at`).run(p);
  logActivity("product", `Upsert product ${p.sku}`, p.name);
  res.status(201).json(p);
});

app.put("/api/products/:sku", (req, res) => {
  const body = normalizeProductBody({ ...req.body, sku: req.params.sku });
  const info = db.prepare(`UPDATE products SET name=@name, category=@category, supplier=@supplier, zone=@zone, stock=@stock, min_stock=@minStock, price=@price, lead_time=@leadTime, supplier_priority=@supplierPriority, description=@description, updated_at=@updatedAt WHERE sku=@sku`).run(body);
  if (!info.changes) return res.status(404).json({ error: "Product not found" });
  logActivity("product", `Update product ${body.sku}`, body.name);
  res.json(body);
});

app.delete("/api/products/:sku", (req, res) => {
  const info = db.prepare("DELETE FROM products WHERE sku = ?").run(String(req.params.sku || "").toUpperCase());
  if (!info.changes) return res.status(404).json({ error: "Product not found" });
  logActivity("product", `Delete product ${String(req.params.sku).toUpperCase()}`, "");
  res.status(204).end();
});

app.get("/api/suppliers", (_req, res) => {
  const rows = db.prepare(`SELECT id, name, contact_email as contactEmail, phone, cost_multiplier as costMultiplier, min_order_value as minOrderValue, default_lead_time as defaultLeadTime, notes, updated_at as updatedAt FROM suppliers ORDER BY name COLLATE NOCASE`).all();
  res.json(rows);
});

app.post("/api/suppliers", (req, res) => {
  const s = normalizeSupplierBody(req.body);
  db.prepare(`INSERT INTO suppliers (id, name, contact_email, phone, cost_multiplier, min_order_value, default_lead_time, notes, updated_at)
              VALUES (@id, @name, @contactEmail, @phone, @costMultiplier, @minOrderValue, @defaultLeadTime, @notes, @updatedAt)
              ON CONFLICT(id) DO UPDATE SET
                name=excluded.name, contact_email=excluded.contact_email, phone=excluded.phone, cost_multiplier=excluded.cost_multiplier,
                min_order_value=excluded.min_order_value, default_lead_time=excluded.default_lead_time, notes=excluded.notes, updated_at=excluded.updated_at`).run(s);
  logActivity("supplier", `Upsert supplier ${s.name}`, s.id);
  res.status(201).json(s);
});

app.put("/api/suppliers/:id", (req, res) => {
  const s = normalizeSupplierBody({ ...req.body, id: req.params.id });
  const info = db.prepare(`UPDATE suppliers SET name=@name, contact_email=@contactEmail, phone=@phone, cost_multiplier=@costMultiplier, min_order_value=@minOrderValue, default_lead_time=@defaultLeadTime, notes=@notes, updated_at=@updatedAt WHERE id=@id`).run(s);
  if (!info.changes) return res.status(404).json({ error: "Supplier not found" });
  logActivity("supplier", `Update supplier ${s.name}`, s.id);
  res.json(s);
});

app.delete("/api/suppliers/:id", (req, res) => {
  const info = db.prepare("DELETE FROM suppliers WHERE id = ?").run(req.params.id);
  if (!info.changes) return res.status(404).json({ error: "Supplier not found" });
  logActivity("supplier", `Delete supplier ${req.params.id}`, "");
  res.status(204).end();
});

app.get("/api/purchase-orders", (_req, res) => {
  const orders = db.prepare(`SELECT id, supplier_id as supplierId, supplier_name as supplierName, status, estimated_value as estimatedValue, eta_days as etaDays, created_at as createdAt, updated_at as updatedAt FROM purchase_orders ORDER BY datetime(created_at) DESC`).all();
  const items = db.prepare(`SELECT purchase_order_id as purchaseOrderId, sku, name, quantity, unit_price as unitPrice, estimated_lead_time as estimatedLeadTime FROM purchase_order_items ORDER BY id`).all();
  const byPo = new Map();
  items.forEach((it) => {
    if (!byPo.has(it.purchaseOrderId)) byPo.set(it.purchaseOrderId, []);
    byPo.get(it.purchaseOrderId).push({ sku: it.sku, name: it.name, quantity: it.quantity, unitPrice: it.unitPrice, estimatedLeadTime: it.estimatedLeadTime });
  });
  res.json(orders.map((o) => ({ ...o, items: byPo.get(o.id) || [] })));
});

app.post("/api/purchase-orders", (req, res) => {
  const po = normalizePurchaseOrderBody(req.body);
  const tx = db.transaction(() => {
    db.prepare(`INSERT INTO purchase_orders (id, supplier_id, supplier_name, status, estimated_value, eta_days, created_at, updated_at)
                VALUES (@id, @supplierId, @supplierName, @status, @estimatedValue, @etaDays, @createdAt, @updatedAt)`).run(po);
    const insertItem = db.prepare(`INSERT INTO purchase_order_items (purchase_order_id, sku, name, quantity, unit_price, estimated_lead_time)
                                   VALUES (@purchaseOrderId, @sku, @name, @quantity, @unitPrice, @estimatedLeadTime)`);
    po.items.forEach((it) => insertItem.run({ purchaseOrderId: po.id, ...it }));
  });
  tx();
  logActivity("restock", `Create PO ${po.id}`, po.supplierName);
  res.status(201).json(po);
});

app.put("/api/purchase-orders/:id", (req, res) => {
  const existing = db.prepare("SELECT id FROM purchase_orders WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "PO not found" });
  const po = normalizePurchaseOrderBody({ ...req.body, id: req.params.id });
  const tx = db.transaction(() => {
    db.prepare(`UPDATE purchase_orders SET supplier_id=@supplierId, supplier_name=@supplierName, status=@status, estimated_value=@estimatedValue, eta_days=@etaDays, updated_at=@updatedAt WHERE id=@id`).run(po);
    db.prepare("DELETE FROM purchase_order_items WHERE purchase_order_id = ?").run(po.id);
    const insertItem = db.prepare(`INSERT INTO purchase_order_items (purchase_order_id, sku, name, quantity, unit_price, estimated_lead_time)
                                   VALUES (@purchaseOrderId, @sku, @name, @quantity, @unitPrice, @estimatedLeadTime)`);
    po.items.forEach((it) => insertItem.run({ purchaseOrderId: po.id, ...it }));
  });
  tx();
  logActivity("restock", `Update PO ${po.id}`, po.status);
  res.json(po);
});

app.delete("/api/purchase-orders/:id", (req, res) => {
  const info = db.prepare("DELETE FROM purchase_orders WHERE id = ?").run(req.params.id);
  if (!info.changes) return res.status(404).json({ error: "PO not found" });
  logActivity("restock", `Delete PO ${req.params.id}`, "");
  res.status(204).end();
});

app.get("/api/activities", (req, res) => {
  const limit = Math.max(1, Math.min(200, Number(req.query.limit || 50)));
  const rows = db.prepare("SELECT id, type, title, detail, at FROM activities ORDER BY datetime(at) DESC LIMIT ?").all(limit);
  res.json(rows);
});

app.post("/api/activities", (req, res) => {
  const row = {
    id: String(req.body?.id || `act-${Date.now()}`),
    type: String(req.body?.type || "info"),
    title: String(req.body?.title || "Event"),
    detail: String(req.body?.detail || ""),
    at: req.body?.at || new Date().toISOString(),
  };
  db.prepare("INSERT OR REPLACE INTO activities (id, type, title, detail, at) VALUES (@id, @type, @title, @detail, @at)").run(row);
  res.status(201).json(row);
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`Warehouse Flow server running on http://localhost:${PORT}`);
});

function normalizeProductBody(body = {}) {
  return {
    sku: String(body.sku || "").trim().toUpperCase(),
    name: String(body.name || "").trim(),
    category: String(body.category || "").trim(),
    supplier: String(body.supplier || "").trim(),
    zone: ["A", "B", "C", "D"].includes(String(body.zone || "A").toUpperCase()) ? String(body.zone || "A").toUpperCase() : "A",
    stock: nnInt(body.stock),
    minStock: nnInt(body.minStock),
    price: nn(body.price),
    leadTime: nnInt(body.leadTime),
    supplierPriority: ["high", "medium", "low"].includes(body.supplierPriority) ? body.supplierPriority : "medium",
    description: String(body.description || "").trim(),
    updatedAt: new Date().toISOString(),
  };
}

function normalizeSupplierBody(body = {}) {
  return {
    id: String(body.id || body.name || "").trim().toLowerCase().replace(/[^a-z0-9а-я]+/gi, "-") || `sup-${Date.now()}`,
    name: String(body.name || "").trim(),
    contactEmail: String(body.contactEmail || "").trim(),
    phone: String(body.phone || "").trim(),
    costMultiplier: Math.max(0.5, nn(body.costMultiplier || 1)),
    minOrderValue: nn(body.minOrderValue),
    defaultLeadTime: nnInt(body.defaultLeadTime),
    notes: String(body.notes || "").trim(),
    updatedAt: new Date().toISOString(),
  };
}

function normalizePurchaseOrderBody(body = {}) {
  const statuses = ["draft", "sent", "received"];
  const items = Array.isArray(body.items) ? body.items.map((it) => ({
    sku: String(it.sku || "").trim().toUpperCase(),
    name: String(it.name || "").trim(),
    quantity: nnInt(it.quantity),
    unitPrice: nn(it.unitPrice),
    estimatedLeadTime: nnInt(it.estimatedLeadTime),
  })).filter((it) => it.sku && it.quantity > 0) : [];
  return {
    id: String(body.id || `PO-${Date.now()}`),
    supplierId: String(body.supplierId || ""),
    supplierName: String(body.supplierName || "").trim(),
    status: statuses.includes(body.status) ? body.status : "draft",
    estimatedValue: nn(body.estimatedValue),
    etaDays: nnInt(body.etaDays),
    createdAt: body.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    items,
  };
}

function logActivity(type, title, detail) {
  db.prepare("INSERT INTO activities (id, type, title, detail, at) VALUES (?, ?, ?, ?, ?)")
    .run(`act-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, type, title, detail || "", new Date().toISOString());
}

function nn(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.round(n * 100) / 100;
}

function nnInt(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.round(n);
}
