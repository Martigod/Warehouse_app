﻿import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";

export function createDb(dbFile) {
  const resolved = path.resolve(process.cwd(), dbFile);
  fs.mkdirSync(path.dirname(resolved), { recursive: true });
  const db = new Database(resolved);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  initSchema(db);
  seedDefaults(db);
  return db;
}

function initSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS products (
      sku TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      category TEXT DEFAULT '',
      supplier TEXT DEFAULT '',
      zone TEXT DEFAULT 'A',
      stock INTEGER NOT NULL DEFAULT 0,
      min_stock INTEGER NOT NULL DEFAULT 0,
      price REAL NOT NULL DEFAULT 0,
      lead_time INTEGER NOT NULL DEFAULT 0,
      supplier_priority TEXT NOT NULL DEFAULT 'medium',
      description TEXT DEFAULT '',
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      contact_email TEXT DEFAULT '',
      phone TEXT DEFAULT '',
      cost_multiplier REAL NOT NULL DEFAULT 1,
      min_order_value REAL NOT NULL DEFAULT 0,
      default_lead_time INTEGER NOT NULL DEFAULT 0,
      notes TEXT DEFAULT '',
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS purchase_orders (
      id TEXT PRIMARY KEY,
      supplier_id TEXT DEFAULT '',
      supplier_name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft',
      estimated_value REAL NOT NULL DEFAULT 0,
      eta_days INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS purchase_order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_order_id TEXT NOT NULL,
      sku TEXT NOT NULL,
      name TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit_price REAL NOT NULL,
      estimated_lead_time INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS activities (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      detail TEXT DEFAULT '',
      at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_purchase_orders_status ON purchase_orders(status);
    CREATE INDEX IF NOT EXISTS idx_activities_at ON activities(at DESC);
  `);
}

function seedDefaults(db) {
  const count = db.prepare("SELECT COUNT(*) AS c FROM activities").get().c;
  if (!count) {
    db.prepare("INSERT INTO activities (id, type, title, detail, at) VALUES (?, ?, ?, ?, ?)")
      .run("seed-1", "system", "Backend schema initialized", "SQLite DB ready", new Date().toISOString());
  }
}
