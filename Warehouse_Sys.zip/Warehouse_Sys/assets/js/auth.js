﻿const SESSION_KEY = "warehouse-auth-session-v1";

const USERS = [
  { username: "admin", password: "admin123", role: "admin", displayName: "Admin" },
  { username: "manager", password: "manager123", role: "manager", displayName: "Warehouse Manager" },
  { username: "operator", password: "operator123", role: "operator", displayName: "Warehouse Operator" },
];

const ROLE_CONFIG = {
  operator: {
    pages: ["dashboard", "inventory", "orders"],
    permissions: [
      "system.export",
      "products.write",
      "stock.move",
      "orders.simulate",
      "orders.process",
    ],
  },
  manager: {
    pages: ["dashboard", "inventory", "suppliers", "restock", "orders"],
    permissions: [
      "system.export",
      "system.seed",
      "products.write",
      "stock.move",
      "import.run",
      "suppliers.write",
      "restock.generate",
      "restock.manage",
      "orders.simulate",
      "orders.process",
    ],
  },
  admin: {
    pages: ["dashboard", "inventory", "suppliers", "restock", "orders"],
    permissions: [
      "system.export",
      "system.seed",
      "products.write",
      "products.delete",
      "stock.move",
      "import.run",
      "suppliers.write",
      "suppliers.delete",
      "restock.generate",
      "restock.manage",
      "restock.delete",
      "orders.simulate",
      "orders.process",
    ],
  },
};

export function getDemoUsers() {
  return USERS.map(({ username, role, displayName }) => ({ username, role, displayName }));
}

export function login({ username, password }) {
  const user = USERS.find((u) => u.username === String(username || "").trim() && u.password === String(password || ""));
  if (!user) throw new Error("Невалидно потребителско име или парола.");
  const session = {
    username: user.username,
    role: user.role,
    displayName: user.displayName,
    loginAt: new Date().toISOString(),
  };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
}

export function logout() {
  localStorage.removeItem(SESSION_KEY);
}

export function getSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !parsed.username || !parsed.role) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function requireAuth({ page }) {
  const session = getSession();
  if (!session) {
    redirectToLogin();
    return null;
  }
  if (page && !canAccessPage(page, session.role)) {
    location.href = "index.html";
    return null;
  }
  return session;
}

export function can(permission, session = getSession()) {
  if (!session) return false;
  const cfg = ROLE_CONFIG[session.role];
  return !!cfg && cfg.permissions.includes(permission);
}

export function canAccessPage(page, roleOrSession) {
  const role = typeof roleOrSession === "string" ? roleOrSession : roleOrSession?.role;
  const cfg = ROLE_CONFIG[role];
  return !!cfg && cfg.pages.includes(page);
}

export function getAccessiblePages(session = getSession()) {
  if (!session) return [];
  const cfg = ROLE_CONFIG[session.role];
  return cfg ? [...cfg.pages] : [];
}

function redirectToLogin() {
  const current = location.pathname.split(/[\\/]/).pop() || "index.html";
  const next = encodeURIComponent(current);
  location.href = `login.html?next=${next}`;
}
