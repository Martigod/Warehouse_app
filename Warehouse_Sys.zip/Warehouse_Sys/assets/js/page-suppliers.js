﻿import { setupAppShell, mount, setToolbarActions } from "./layout.js";
import { store } from "./store.js";
import { escapeHtml } from "./utils.js";
import { can } from "./auth.js";

const appRoot = setupAppShell({
  page: "suppliers",
  title: "Доставчици",
  subtitle: "Управление на доставчици, контакти и параметри за автоматично дозареждане.",
});

function render() {
  const suppliers = store.getSuppliers();
  const products = store.getProducts();
  const perms = {
    write: can("suppliers.write"),
    del: can("suppliers.delete"),
    gen: can("restock.generate"),
  };

  mount(`
    <div class="two-col">
      <section class="panel">
        <div class="panel-header"><div><h3>Добавяне / редакция на доставчик</h3><p>Контакти и правила за заявка</p></div></div>
        <form id="supplierForm" class="stack">
          <input type="hidden" name="id" />
          <label>Име<input name="name" required placeholder="TechSupply BG" /></label>
          <div class="grid cols-2">
            <label>Email<input name="contactEmail" placeholder="ops@supplier.com" /></label>
            <label>Телефон<input name="phone" placeholder="+359..." /></label>
          </div>
          <div class="grid cols-3">
            <label>Cost multiplier<input name="costMultiplier" type="number" step="0.01" min="0.5" value="1" /></label>
            <label>Мин. поръчка (лв)<input name="minOrderValue" type="number" step="0.01" min="0" value="0" /></label>
            <label>Lead time (дни)<input name="defaultLeadTime" type="number" min="0" value="0" /></label>
          </div>
          <label>Бележки<textarea name="notes" rows="4" placeholder="SLA, ограничения, условия..."></textarea></label>
          <div class="actions"><button class="btn-primary" type="submit" ${perms.write ? "" : "disabled"}>Запази доставчик</button><button class="btn-ghost" type="reset">Изчисти</button><span id="supplierStatus" class="inline-status"></span></div>
        </form>
      </section>

      <section class="panel">
        <div class="panel-header"><div><h3>Обобщение</h3><p>Статистика по доставчици</p></div></div>
        <div class="stats" style="grid-template-columns:repeat(2,minmax(0,1fr));">
          <article class="stat-card"><div class="k">Общо доставчици</div><div class="v">${suppliers.length}</div><div class="h">В системата</div></article>
          <article class="stat-card"><div class="k">Open заявки</div><div class="v">${store.getPurchaseOrders().filter((p) => p.status !== "received").length}</div><div class="h">Чернови/изпратени</div></article>
        </div>
        <p class="note" style="margin-top:10px;">Използвай бутона „Заявка“ за конкретен доставчик или генерирай автоматично от страницата „Дозареждане“.</p>
      </section>
    </div>

    <section class="panel">
      <div class="panel-header"><div><h3>Списък доставчици</h3><p>Връзка към продукти и ниска наличност</p></div></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Доставчик</th><th>Контакти</th><th>Продукти</th><th>Ниска наличност</th><th>Lead</th><th>Действия</th></tr></thead>
          <tbody>
            ${suppliers.length ? suppliers.map((s) => {
              const related = products.filter((p) => (p.supplier || "").trim().toLowerCase() === s.name.trim().toLowerCase());
              const low = related.filter((p) => p.stock <= p.minStock).length;
              return `<tr>
                <td><strong>${escapeHtml(s.name)}</strong></td>
                <td>${escapeHtml(s.contactEmail || s.phone || "-")}</td>
                <td>${related.length}</td>
                <td>${low}</td>
                <td>${s.defaultLeadTime} дни</td>
                <td><div class="actions"><button class="btn-ghost btn-sm" data-action="edit" data-id="${escapeHtml(s.id)}" ${perms.write ? "" : "disabled"}>Редакция</button>${perms.gen ? `<button class="btn-secondary btn-sm" data-action="draft" data-id="${escapeHtml(s.id)}">Заявка</button>` : ""}${perms.del ? `<button class="btn-danger btn-sm" data-action="delete" data-id="${escapeHtml(s.id)}">Изтрий</button>` : ""}</div></td>
              </tr>`;
            }).join("") : `<tr><td colspan="6" class="empty">Няма доставчици.</td></tr>`}
          </tbody>
        </table>
      </div>
    </section>
  `);

  wireEvents();
  setToolbarActions([{ label: "Авто дозареждане", className: "btn-secondary", permission: "restock.generate", onClick: () => store.generateRestockOrders() }]);
}

function wireEvents() {
  const status = document.getElementById("supplierStatus");
  const form = document.getElementById("supplierForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!can("suppliers.write")) {
      status.className = "inline-status error";
      status.textContent = "Нямаш права да редактираш доставчици.";
      return;
    }
    const fd = new FormData(form);
    try {
      store.upsertSupplier(Object.fromEntries(fd.entries()));
      status.className = "inline-status success";
      status.textContent = "Доставчикът е записан.";
      form.reset();
      form.elements.namedItem("costMultiplier").value = 1;
      form.elements.namedItem("minOrderValue").value = 0;
      form.elements.namedItem("defaultLeadTime").value = 0;
    } catch (err) {
      status.className = "inline-status error";
      status.textContent = err.message;
    }
  });

  form.addEventListener("reset", () => {
    setTimeout(() => {
      form.elements.namedItem("id").value = "";
      status.textContent = "";
    }, 0);
  });

  document.querySelector("tbody").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;
    const supplier = store.getSuppliers().find((s) => s.id === btn.dataset.id);
    if (!supplier) return;
    if (btn.dataset.action === "edit") {
      if (!can("suppliers.write")) return;
      Object.entries(supplier).forEach(([k, v]) => {
        const field = form.elements.namedItem(k);
        if (field) field.value = v ?? "";
      });
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    if (btn.dataset.action === "delete") {
      if (!can("suppliers.delete")) return;
      if (confirm(`Изтриване на доставчик ${supplier.name}?`)) store.deleteSupplier(supplier.id);
      return;
    }
    if (btn.dataset.action === "draft") {
      if (!can("restock.generate")) return;
      const res = store.generateRestockOrders({ supplierId: supplier.id });
      status.className = `inline-status ${res.created ? "success" : "info"}`;
      status.textContent = res.created ? `Генерирани ${res.created} заявки.` : "Няма нови заявки за този доставчик.";
    }
  });
}

if (appRoot) {
  store.subscribe(render);
  render();
}
