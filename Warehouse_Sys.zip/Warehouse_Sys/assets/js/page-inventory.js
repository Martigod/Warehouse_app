﻿import { setupAppShell, mount, setToolbarActions } from "./layout.js";
import { store } from "./store.js";
import { downloadTextFile, escapeHtml, formatCurrency } from "./utils.js";
import { can } from "./auth.js";

const appRoot = setupAppShell({
  page: "inventory",
  title: "Наличности",
  subtitle: "Продуктов каталог, движения на стока, търсене, филтриране и импорт.",
});

let ui = { search: "", category: "all", stockFilter: "all", sortBy: "name" };

function render() {
  const state = store.getState();
  const perms = {
    productsWrite: can("products.write"),
    productsDelete: can("products.delete"),
    stockMove: can("stock.move"),
    importRun: can("import.run"),
  };
  const categories = [...new Set(state.products.map((p) => p.category).filter(Boolean))].sort((a, b) => a.localeCompare(b, "bg"));
  const filtered = filterProducts(state.products);

  mount(`
    <div class="card-grid">
      <section class="panel">
        <div class="panel-header"><div><h3>Добавяне / редакция на продукт</h3><p>SKU е уникален идентификатор</p></div></div>
        <form id="productForm" class="stack">
          <div class="grid cols-2">
            <label>SKU<input name="sku" required placeholder="SKU-001" /></label>
            <label>Име<input name="name" required placeholder="Индустриален сензор" /></label>
          </div>
          <div class="grid cols-2">
            <label>Категория<input name="category" placeholder="Електроника" /></label>
            <label>Доставчик<input name="supplier" list="supplierNames" placeholder="TechSupply BG" /></label>
          </div>
          <datalist id="supplierNames">${state.suppliers.map((s) => `<option value="${escapeHtml(s.name)}"></option>`).join("")}</datalist>
          <div class="grid cols-4">
            <label>Зона<select name="zone"><option>A</option><option>B</option><option>C</option><option>D</option></select></label>
            <label>Наличност<input type="number" min="0" name="stock" value="0" /></label>
            <label>Мин. праг<input type="number" min="0" name="minStock" value="0" /></label>
            <label>Цена (лв)<input type="number" step="0.01" min="0" name="price" value="0" /></label>
          </div>
          <div class="grid cols-3">
            <label>Lead time (дни)<input type="number" min="0" name="leadTime" value="2" /></label>
            <label>Приоритет<select name="supplierPriority"><option>high</option><option selected>medium</option><option>low</option></select></label>
            <label>&nbsp;<button class="btn-primary" type="submit" ${perms.productsWrite ? "" : "disabled"}>Запази продукт</button></label>
          </div>
          <label>Описание<textarea rows="3" name="description" placeholder="Описание..."></textarea></label>
          <div class="actions"><button class="btn-ghost" type="reset">Изчисти</button><span id="productStatus" class="inline-status"></span></div>
        </form>
      </section>

      <section class="panel stack">
        <div>
          <div class="panel-header"><div><h3>Движение на стока</h3><p>Входящо / изходящо</p></div></div>
          <form id="movementForm" class="stack">
            <label>SKU<input name="sku" required placeholder="SKU-001" /></label>
            <div class="grid cols-2">
              <label>Тип<select name="type"><option value="in">Входящо (+)</option><option value="out">Изходящо (-)</option></select></label>
              <label>Количество<input type="number" min="1" name="quantity" value="1" /></label>
            </div>
            <label>Бележка<input name="note" placeholder="Доставка / корекция" /></label>
            <div class="actions"><button class="btn-primary" type="submit" ${perms.stockMove ? "" : "disabled"}>Запиши движение</button><span id="movementStatus" class="inline-status"></span></div>
          </form>
        </div>

        <div>
          <div class="panel-header"><div><h3>Импорт</h3><p>CSV / JSON за продукти и доставчици</p></div></div>
          <form id="importForm" class="stack">
            <div class="grid cols-2">
              <label>Тип<select name="target"><option value="products">Продукти</option><option value="suppliers">Доставчици</option></select></label>
              <label>Режим<select name="mode"><option value="merge">Merge</option><option value="replace">Replace</option></select></label>
            </div>
            <label>Файл<input type="file" name="file" accept=".json,.csv" /></label>
            <div class="actions">
              <button class="btn-primary" type="submit" ${perms.importRun ? "" : "disabled"}>Импорт</button>
              <button class="btn-ghost" type="button" id="downloadTemplatesBtn">Шаблони CSV</button>
              <span id="importStatus" class="inline-status"></span>
            </div>
          </form>
          <p class="note">Products CSV: <code>sku,name,category,supplier,zone,stock,minStock,price,leadTime,supplierPriority,description</code>${perms.importRun ? "" : " (само manager/admin)"}</p>
          <p class="note">Suppliers CSV: <code>name,contactEmail,phone,costMultiplier,minOrderValue,defaultLeadTime,notes</code></p>
        </div>
      </section>
    </div>

    <section class="panel">
      <div class="panel-header"><div><h3>Каталог и наличности</h3><p>Търсене, филтриране и бърза редакция</p></div></div>
      <div class="grid cols-4" style="margin-bottom:10px;">
        <label>Търсене<input id="searchInput" value="${escapeHtml(ui.search)}" placeholder="SKU, име, категория, доставчик, описание" /></label>
        <label>Категория<select id="categoryFilter"><option value="all">Всички</option>${categories.map((c) => `<option value="${escapeHtml(c)}" ${ui.category === c ? "selected" : ""}>${escapeHtml(c)}</option>`).join("")}</select></label>
        <label>Статус<select id="stockFilter"><option value="all">Всички</option><option value="low" ${ui.stockFilter === "low" ? "selected" : ""}>Ниска наличност</option><option value="ok" ${ui.stockFilter === "ok" ? "selected" : ""}>Нормална</option></select></label>
        <label>Сортиране<select id="sortBy"><option value="name" ${ui.sortBy === "name" ? "selected" : ""}>Име</option><option value="stock-desc" ${ui.sortBy === "stock-desc" ? "selected" : ""}>Наличност ↓</option><option value="stock-asc" ${ui.sortBy === "stock-asc" ? "selected" : ""}>Наличност ↑</option><option value="value-desc" ${ui.sortBy === "value-desc" ? "selected" : ""}>Стойност ↓</option><option value="zone" ${ui.sortBy === "zone" ? "selected" : ""}>Зона</option></select></label>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>SKU</th><th>Продукт</th><th>Категория</th><th>Зона</th><th>Наличност</th><th>Мин</th><th>Цена</th><th>Стойност</th><th>Доставчик</th><th>Описание</th><th>Действия</th></tr></thead>
          <tbody id="catalogTbody">
            ${filtered.length ? filtered.map((p) => renderProductRow(p, perms)).join("") : `<tr><td colspan="11" class="empty">Няма продукти по текущите филтри.</td></tr>`}
          </tbody>
        </table>
      </div>
    </section>
  `);

  wireEvents();
  setToolbarActions([
    { label: "Генерирай дозареждане", className: "btn-secondary", permission: "restock.generate", onClick: () => store.generateRestockOrders() },
  ]);
}

function wireEvents() {
  const productStatus = document.getElementById("productStatus");
  const movementStatus = document.getElementById("movementStatus");
  const importStatus = document.getElementById("importStatus");

  document.getElementById("productForm").addEventListener("submit", (e) => {
    e.preventDefault();
    if (!can("products.write")) {
      productStatus.className = "inline-status error";
      productStatus.textContent = "Нямаш права да записваш продукти.";
      return;
    }
    const fd = new FormData(e.currentTarget);
    try {
      store.upsertProduct(Object.fromEntries(fd.entries()));
      productStatus.className = "inline-status success";
      productStatus.textContent = "Продуктът е записан.";
      e.currentTarget.reset();
    } catch (err) {
      productStatus.className = "inline-status error";
      productStatus.textContent = err.message;
    }
  });

  document.getElementById("movementForm").addEventListener("submit", (e) => {
    e.preventDefault();
    if (!can("stock.move")) {
      movementStatus.className = "inline-status error";
      movementStatus.textContent = "Нямаш права за движение на стока.";
      return;
    }
    const fd = new FormData(e.currentTarget);
    try {
      store.applyStockMovement(Object.fromEntries(fd.entries()));
      movementStatus.className = "inline-status success";
      movementStatus.textContent = "Движението е записано.";
      e.currentTarget.reset();
      e.currentTarget.querySelector('[name="type"]').value = "in";
      e.currentTarget.querySelector('[name="quantity"]').value = 1;
    } catch (err) {
      movementStatus.className = "inline-status error";
      movementStatus.textContent = err.message;
    }
  });

  document.getElementById("importForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!can("import.run")) {
      importStatus.className = "inline-status error";
      importStatus.textContent = "Импортът е позволен само за manager/admin.";
      return;
    }
    const fd = new FormData(e.currentTarget);
    const file = fd.get("file");
    if (!(file instanceof File) || !file.name) {
      importStatus.className = "inline-status error";
      importStatus.textContent = "Избери файл.";
      return;
    }
    try {
      const result = await store.importFromFile(file, { target: fd.get("target"), mode: fd.get("mode") });
      importStatus.className = "inline-status success";
      importStatus.textContent = `Импорт: ${result.created} нови, ${result.updated} обновени, ${result.skipped} пропуснати.`;
    } catch (err) {
      importStatus.className = "inline-status error";
      importStatus.textContent = err.message;
    }
  });

  document.getElementById("downloadTemplatesBtn").addEventListener("click", () => {
    downloadTextFile("products-template.csv", "sku,name,category,supplier,zone,stock,minStock,price,leadTime,supplierPriority,description\nSKU-100,Примерен продукт,Категория,TechSupply BG,A,10,5,25.5,3,medium,Описание", "text/csv");
    setTimeout(() => downloadTextFile("suppliers-template.csv", "name,contactEmail,phone,costMultiplier,minOrderValue,defaultLeadTime,notes\nTechSupply BG,ops@techsupply.bg,+359888000000,1,100,3,Основен доставчик", "text/csv"), 120);
    importStatus.className = "inline-status info";
    importStatus.textContent = "Свалени са CSV шаблони за products/suppliers.";
  });

  document.getElementById("searchInput").addEventListener("input", (e) => { ui.search = e.target.value.trim().toLowerCase(); render(); });
  document.getElementById("categoryFilter").addEventListener("change", (e) => { ui.category = e.target.value; render(); });
  document.getElementById("stockFilter").addEventListener("change", (e) => { ui.stockFilter = e.target.value; render(); });
  document.getElementById("sortBy").addEventListener("change", (e) => { ui.sortBy = e.target.value; render(); });

  const catalogTbody = document.getElementById("catalogTbody");
  if (!catalogTbody) return;
  catalogTbody.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;
    const sku = btn.dataset.sku;
    const product = store.getProducts().find((p) => p.sku === sku);
    if (!product) return;
    if (btn.dataset.action === "delete") {
      if (!can("products.delete")) return;
      if (confirm(`Изтриване на ${sku}?`)) store.deleteProduct(sku);
      return;
    }
    if (btn.dataset.action === "edit") {
      if (!can("products.write")) return;
      fillProductForm(product);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  });
}

function fillProductForm(product) {
  const form = document.getElementById("productForm");
  Object.entries(product).forEach(([k, v]) => {
    const field = form.elements.namedItem(k);
    if (field) field.value = v ?? "";
  });
}

function renderProductRow(p, perms) {
  const status = p.stock === 0 ? "critical" : p.stock <= p.minStock ? "low" : "ok";
  return `<tr>
    <td class="mono">${escapeHtml(p.sku)}</td>
    <td><strong>${escapeHtml(p.name)}</strong><div class="note">Lead ${p.leadTime} дни • ${escapeHtml(p.supplierPriority)}</div></td>
    <td>${escapeHtml(p.category || "-")}</td>
    <td>${escapeHtml(p.zone)}</td>
    <td><span class="pill ${status}">${p.stock}</span></td>
    <td>${p.minStock}</td>
    <td>${formatCurrency(p.price)}</td>
    <td>${formatCurrency(p.price * p.stock)}</td>
    <td>${escapeHtml(p.supplier || "-")}</td>
    <td>${escapeHtml(p.description || "-")}</td>
    <td><div class="actions"><button class="btn-ghost btn-sm" data-action="edit" data-sku="${escapeHtml(p.sku)}" ${perms.productsWrite ? "" : "disabled"}>Редакция</button>${perms.productsDelete ? `<button class="btn-danger btn-sm" data-action="delete" data-sku="${escapeHtml(p.sku)}">Изтрий</button>` : ""}</div></td>
  </tr>`;
}

function filterProducts(products) {
  let list = [...products];
  if (ui.search) list = list.filter((p) => [p.sku, p.name, p.category, p.supplier, p.description].join(" ").toLowerCase().includes(ui.search));
  if (ui.category !== "all") list = list.filter((p) => p.category === ui.category);
  if (ui.stockFilter === "low") list = list.filter((p) => p.stock <= p.minStock);
  if (ui.stockFilter === "ok") list = list.filter((p) => p.stock > p.minStock);
  switch (ui.sortBy) {
    case "stock-desc": list.sort((a, b) => b.stock - a.stock); break;
    case "stock-asc": list.sort((a, b) => a.stock - b.stock); break;
    case "value-desc": list.sort((a, b) => b.stock * b.price - a.stock * a.price); break;
    case "zone": list.sort((a, b) => a.zone.localeCompare(b.zone)); break;
    default: list.sort((a, b) => a.name.localeCompare(b.name, "bg"));
  }
  return list;
}

if (appRoot) {
  store.subscribe(render);
  render();
}
