﻿import { login, getDemoUsers, getSession } from "./auth.js";

if (getSession()) {
  const next = new URLSearchParams(location.search).get("next") || "index.html";
  location.href = next;
}

document.body.innerHTML = `
  <div class="app-shell" style="grid-template-columns:1fr;min-height:100vh;align-items:center;justify-items:center;">
    <main class="main-wrap" style="width:min(960px,100%);display:grid;gap:16px;">
      <section class="panel" style="max-width:560px;justify-self:center;width:100%;">
        <div class="panel-header"><div><h3>Вход в системата</h3><p>Избери роля или въведи данни за достъп</p></div></div>
        <form id="loginForm" class="stack">
          <label>Потребител<input name="username" required autocomplete="username" placeholder="admin" /></label>
          <label>Парола<input name="password" type="password" required autocomplete="current-password" placeholder="admin123" /></label>
          <div class="actions"><button class="btn-primary" type="submit">Вход</button><span id="loginStatus" class="inline-status"></span></div>
        </form>
      </section>
      <section class="panel" style="max-width:860px;justify-self:center;width:100%;">
        <div class="panel-header"><div><h3>Демо акаунти</h3><p>Role-based достъп за тест</p></div></div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Потребител</th><th>Роля</th><th>Парола</th><th>Достъп</th><th>Действие</th></tr></thead>
            <tbody>
              ${getDemoUsers().map((u) => `<tr>
                <td><strong>${u.username}</strong></td>
                <td>${u.role}</td>
                <td>${u.username}123</td>
                <td>${describeRole(u.role)}</td>
                <td><button class="btn-ghost btn-sm" data-quick-login="${u.username}">Влез като ${u.role}</button></td>
              </tr>`).join("")}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </div>`;

const form = document.getElementById("loginForm");
const status = document.getElementById("loginStatus");
form.addEventListener("submit", (e) => {
  e.preventDefault();
  const fd = new FormData(form);
  try {
    login({ username: fd.get("username"), password: fd.get("password") });
    const next = new URLSearchParams(location.search).get("next") || "index.html";
    location.href = next;
  } catch (err) {
    status.className = "inline-status error";
    status.textContent = err.message;
  }
});

document.querySelector("tbody").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-quick-login]");
  if (!btn) return;
  const username = btn.dataset.quickLogin;
  form.elements.namedItem("username").value = username;
  form.elements.namedItem("password").value = `${username}123`;
  form.requestSubmit();
});

function describeRole(role) {
  if (role === "operator") return "Dashboard, Наличности, Поръчки";
  if (role === "manager") return "+ Доставчици, Дозареждане, Импорт";
  return "Пълен достъп (вкл. delete)";
}
