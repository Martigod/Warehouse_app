﻿import { downloadTextFile } from "./utils.js";
import { store } from "./store.js";
import { can, canAccessPage, getAccessiblePages, getSession, logout, requireAuth } from "./auth.js";

const pages = [
  { key: "dashboard", href: "index.html", label: "Dashboard" },
  { key: "inventory", href: "inventory.html", label: "Наличности" },
  { key: "suppliers", href: "suppliers.html", label: "Доставчици" },
  { key: "restock", href: "restock.html", label: "Дозареждане" },
  { key: "orders", href: "orders.html", label: "Поръчки" },
];

export function setupAppShell({ page, title, subtitle }) {
  const session = requireAuth({ page });
  if (!session) return null;
  store.init();

  document.body.innerHTML = `
    <div class="app-shell">
      <aside class="sidebar" id="sidebar"></aside>
      <main class="main-wrap">
        <header class="topbar" id="topbar"></header>
        <div id="page-root" class="page-layout"></div>
      </main>
    </div>`;

  renderSidebar(page, session);
  renderTopbar(title, subtitle, session);
  return document.getElementById("page-root");
}

function renderSidebar(activePage, session) {
  const allowed = new Set(getAccessiblePages(session));
  const visiblePages = pages.filter((p) => allowed.has(p.key));
  const sidebar = document.getElementById("sidebar");
  sidebar.innerHTML = `
    <div class="brand">
      <p class="eyebrow">Автономен склад</p>
      <h1>Warehouse Flow</h1>
      <p>Модулна система за наличности, доставчици и оптимизирани поръчки.</p>
    </div>
    <nav class="nav-group">
      ${visiblePages.map((p) => `<a class="nav-link ${p.key === activePage ? "active" : ""}" href="${p.href}"><span>${p.label}</span></a>`).join("")}
    </nav>
    <div class="sidebar-actions">
      <button class="btn-secondary" id="globalSeedBtn" ${can("system.seed", session) ? "" : "disabled"}>Зареди примерни данни</button>
      <button class="btn-secondary" id="globalExportBtn" ${can("system.export", session) ? "" : "disabled"}>Експорт JSON</button>
      <button class="btn-ghost" id="logoutBtn">Изход</button>
    </div>
    <div class="nav-note">Потребител: <strong>${session.displayName || session.username}</strong><br/>Роля: <strong>${session.role}</strong></div>`;

  sidebar.querySelector("#globalSeedBtn").addEventListener("click", () => {
    if (!can("system.seed", session)) return;
    store.seedSampleData();
  });
  sidebar.querySelector("#globalExportBtn").addEventListener("click", () => {
    if (!can("system.export", session)) return;
    const snapshot = store.exportSnapshot();
    downloadTextFile(`warehouse-export-${new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-")}.json`, JSON.stringify(snapshot, null, 2), "application/json");
  });
  sidebar.querySelector("#logoutBtn").addEventListener("click", () => {
    logout();
    location.href = "login.html";
  });
}

function renderTopbar(title, subtitle, session) {
  const topbar = document.getElementById("topbar");
  topbar.innerHTML = `
    <div>
      <h2>${title}</h2>
      <p>${subtitle}</p>
    </div>
    <div class="toolbar" id="toolbar-slot">
      <span id="toolbar-meta"><span class="pill ok">${session.role}</span> <span class="note">${session.displayName || session.username}</span></span>
    </div>`;
}

export function setToolbarActions(actions) {
  const slot = document.getElementById("toolbar-slot");
  if (!slot) return;
  const meta = slot.querySelector("#toolbar-meta");
  const metaHtml = meta ? meta.outerHTML : "";
  slot.innerHTML = metaHtml;
  actions.forEach((action) => {
    if (action.permission && !can(action.permission, getSession())) return;
    const btn = document.createElement("button");
    btn.className = action.className || "btn-secondary";
    btn.textContent = action.label;
    if (action.disabled) btn.disabled = true;
    btn.addEventListener("click", action.onClick);
    slot.appendChild(btn);
  });
}

export function mount(html) {
  const root = document.getElementById("page-root");
  root.innerHTML = html;
  return root;
}

export function guardPageAccess(page) {
  const session = getSession();
  return !!session && canAccessPage(page, session);
}
