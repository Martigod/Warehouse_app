﻿import { clampNonNegative, clampNonNegativeInt, round2, zoneWeight, priorityWeight } from "./utils.js";

export function parseOrderLines(text) {
  const errors = [];
  const lines = [];
  const aggregated = new Map();
  String(text || "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .forEach((line, index) => {
      const m = line.match(/^([^:]+)\s*:\s*(\d+)$/);
      if (!m) {
        errors.push(`Ред ${index + 1}: използвай формат SKU:количество`);
        return;
      }
      const sku = m[1].trim().toUpperCase();
      const quantity = clampNonNegativeInt(m[2]);
      if (!sku || quantity < 1) {
        errors.push(`Ред ${index + 1}: невалидни стойности`);
        return;
      }
      aggregated.set(sku, (aggregated.get(sku) || 0) + quantity);
    });
  for (const [sku, quantity] of aggregated.entries()) lines.push({ sku, quantity });
  return { lines, errors };
}

export function expandOrderWithProducts(lines, products) {
  const errors = [];
  const enriched = [];
  for (const line of lines) {
    const product = products.find((p) => p.sku === line.sku);
    if (!product) {
      errors.push(`SKU ${line.sku} не съществува в каталога.`);
      continue;
    }
    if (product.stock < line.quantity) {
      errors.push(`Недостатъчна наличност за ${line.sku}: налични ${product.stock}, нужни ${line.quantity}.`);
      continue;
    }
    enriched.push({
      ...line,
      product,
      zone: product.zone,
      lineValue: product.price * line.quantity,
      riskScore: computeRiskScore(product),
    });
  }
  return { lines: enriched, errors };
}

function computeRiskScore(product) {
  const stockPressure = product.minStock > 0 ? Math.max(0, (product.minStock - product.stock) / product.minStock) : 0;
  return zoneWeight[product.zone] * 0.9 + product.leadTime * 0.5 + priorityWeight[product.supplierPriority] * 0.7 + stockPressure * 3;
}

export function optimizeOrder(lines, options) {
  if (!lines.length) return { ok: false, errors: ["Няма редове за оптимизация."] };
  const baseline = evaluateSequence(lines, options, "input-order");
  const candidates = buildCandidateSequences(lines, options.mode);
  const evaluated = candidates.map((c) => ({ ...c, metrics: evaluateSequence(c.sequence, options, c.name) }));
  let best = evaluated[0];
  for (const candidate of evaluated.slice(1)) {
    if (isCandidateBetter(candidate.metrics, best.metrics, options.mode)) best = candidate;
  }
  return {
    ok: true,
    baseline,
    selectedStrategy: best.name,
    metrics: best.metrics,
    sequence: best.sequence,
    sequenceSummary: best.sequence.map((line, idx) => ({
      step: idx + 1,
      sku: line.sku,
      quantity: line.quantity,
      zone: line.zone,
      name: line.product.name,
      value: line.lineValue,
    })),
    savings: {
      minutes: Math.max(0, baseline.totalMinutes - best.metrics.totalMinutes),
      cost: Math.max(0, baseline.totalOperationalCost - best.metrics.totalOperationalCost),
      zoneSwitches: Math.max(0, baseline.zoneSwitches - best.metrics.zoneSwitches),
    },
  };
}

function buildCandidateSequences(lines, mode) {
  return dedupeCandidates([
    { name: "input-order", sequence: [...lines] },
    { name: "zone-ascending", sequence: [...lines].sort(compareByZoneThenValueDesc) },
    { name: "zone-descending", sequence: [...lines].sort((a, b) => compareByZoneThenValueDesc(b, a)) },
    { name: "high-value-first", sequence: [...lines].sort((a, b) => b.lineValue - a.lineValue || zoneWeight[a.zone] - zoneWeight[b.zone]) },
    { name: "risk-aware", sequence: [...lines].sort((a, b) => b.riskScore - a.riskScore || zoneWeight[a.zone] - zoneWeight[b.zone]) },
    { name: "cluster-balanced", sequence: clusterByZone(lines, mode) },
  ]);
}

function clusterByZone(lines, mode) {
  const groups = new Map();
  for (const line of lines) {
    if (!groups.has(line.zone)) groups.set(line.zone, []);
    groups.get(line.zone).push(line);
  }
  const zones = [...groups.keys()].sort((a, b) => {
    const ga = groups.get(a);
    const gb = groups.get(b);
    const qtyA = ga.reduce((s, l) => s + l.quantity, 0);
    const qtyB = gb.reduce((s, l) => s + l.quantity, 0);
    const valueA = ga.reduce((s, l) => s + l.lineValue, 0);
    const valueB = gb.reduce((s, l) => s + l.lineValue, 0);
    const scoreA = (mode === "fast" ? -zoneWeight[a] * 3 : 0) + (mode === "cost" ? valueA * 0.05 : 0) + qtyA * 0.8;
    const scoreB = (mode === "fast" ? -zoneWeight[b] * 3 : 0) + (mode === "cost" ? valueB * 0.05 : 0) + qtyB * 0.8;
    return scoreB - scoreA;
  });
  const seq = [];
  for (const z of zones) {
    const group = [...groups.get(z)];
    group.sort((a, b) => {
      if (mode === "cost") return b.lineValue - a.lineValue || b.quantity - a.quantity;
      if (mode === "fast") return b.quantity - a.quantity || b.lineValue - a.lineValue;
      return b.lineValue + b.quantity * 10 - (a.lineValue + a.quantity * 10);
    });
    seq.push(...group);
  }
  return seq;
}

function dedupeCandidates(candidates) {
  const seen = new Set();
  const unique = [];
  for (const c of candidates) {
    const key = c.sequence.map((l) => l.sku).join("|");
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(c);
  }
  return unique;
}

function compareByZoneThenValueDesc(a, b) {
  return zoneWeight[a.zone] - zoneWeight[b.zone] || b.lineValue - a.lineValue || b.quantity - a.quantity;
}

function isCandidateBetter(a, b, mode) {
  if (mode === "fast") {
    if (a.totalMinutes !== b.totalMinutes) return a.totalMinutes < b.totalMinutes;
    return a.totalOperationalCost < b.totalOperationalCost;
  }
  if (mode === "cost") {
    if (a.totalOperationalCost !== b.totalOperationalCost) return a.totalOperationalCost < b.totalOperationalCost;
    return a.totalMinutes < b.totalMinutes;
  }
  const scoreA = a.totalMinutes * 0.55 + a.totalOperationalCost * 0.45;
  const scoreB = b.totalMinutes * 0.55 + b.totalOperationalCost * 0.45;
  if (scoreA !== scoreB) return scoreA < scoreB;
  return a.zoneSwitches < b.zoneSwitches;
}

function evaluateSequence(sequence, options, strategyName) {
  let totalPickMinutes = 0;
  let totalTravelMinutes = 0;
  let zoneSwitches = 0;
  let previousZone = null;

  sequence.forEach((line, idx) => {
    const z = zoneWeight[line.zone] || 1;
    const qty = line.quantity;
    const itemComplexity = 0.18 * qty + 0.08 * Math.max(0, line.product.leadTime - 1);
    const valueCare = line.lineValue > 500 ? 0.35 : line.lineValue > 200 ? 0.18 : 0.06;
    totalPickMinutes += 0.55 + itemComplexity + valueCare;
    if (idx === 0) {
      totalTravelMinutes += 1.4 + z * 0.75;
    } else {
      const prev = zoneWeight[previousZone] || 1;
      const delta = Math.abs(z - prev);
      if (line.zone !== previousZone) zoneSwitches += 1;
      totalTravelMinutes += 0.9 + delta * 0.95 + (line.zone === previousZone ? 0.15 : 0.45);
    }
    previousZone = line.zone;
  });

  if (sequence.length > 1) totalTravelMinutes += 0.45 * Math.max(0, sequence.length - 1);
  const laborRate = clampNonNegative(options.laborRate);
  const switchCost = clampNonNegative(options.zoneSwitchCost);
  const totalMinutes = round2(totalPickMinutes + totalTravelMinutes);
  const laborCost = round2(totalMinutes * laborRate);
  const switchingCost = round2(zoneSwitches * switchCost);
  const totalOperationalCost = round2(laborCost + switchingCost);
  const orderValue = round2(sequence.reduce((sum, l) => sum + l.lineValue, 0));

  return {
    strategyName,
    totalPickMinutes: round2(totalPickMinutes),
    totalTravelMinutes: round2(totalTravelMinutes),
    totalMinutes,
    zoneSwitches,
    laborCost,
    switchingCost,
    totalOperationalCost,
    orderValue,
  };
}
