﻿import { setupAppShell, mount, setToolbarActions } from "./layout.js";
import { store } from "./store.js";
import { escapeHtml, formatCurrency, formatDateTime } from "./utils.js";
import { can } from "./auth.js";

const appRoot = setupAppShell({
  page: "restock",
  title: "Дозареждане",
  subtitle: "Автоматично генерирани заявки по доставчик и проследяване на статуса им.",
});

function render() {
  const orders = store.getPurchaseOrders();
  const perms = { generate: can("restock.generate"), manage: can("restock.manage"), del: can("restock.delete") };
  const draft = orders.filter((o) => o.status === "draft");
  const sent = orders.filter((o) => o.status === "sent");
  const received = orders.filter((o) => o.status === "received");
  const open = [...draft, ...sent];
  const openValue = open.reduce((sum, po) => sum + po.estimatedValue, 0);
  const avgEta = open.length ? open.reduce((sum, po) => sum + po.etaDays, 0) / open.length : 0;

  mount(`
    <section class="panel">
      <div class="stats">
        <article class="stat-card"><div class="k">Draft</div><div class="v">${draft.length}</div><div class="h">Чернови заявки</div></article>
        <article class="stat-card"><div class="k">Sent</div><div class="v">${sent.length}</div><div class="h">Изпратени заявки</div></article>
        <article class="stat-card"><div class="k">Received</div><div class="v">${received.length}</div><div class="h">Получени заявки</div></article>
        <article class="stat-card"><div class="k">Open Value</div><div class="v">${formatCurrency(openValue)}</div><div class="h">ETA ${avgEta.toFixed(1)} дни</div></article>
      </div>
      <div class="actions" style="margin-top:10px;"><button id="generateBtn" class="btn-primary" ${perms.generate ? "" : "disabled"}>Генерирай заявки за дозареждане</button><span id="restockStatus" class="inline-status"></span></div>
    </section>

    <section class="panel">
      <div class="panel-header"><div><h3>Заявки за дозареждане</h3><p>Консолидирани по доставчик</p></div></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Доставчик</th><th>Статус</th><th>Позиции</th><th>Стойност</th><th>ETA</th><th>Създадена</th><th>Действия</th></tr></thead>
          <tbody>
            ${orders.length ? orders.map((po) => `<tr>
              <td class="mono">${escapeHtml(po.id)}</td>
              <td>${escapeHtml(po.supplierName)}</td>
              <td><span class="pill ${po.status}">${escapeHtml(po.status)}</span></td>
              <td>${escapeHtml(po.items.map((i) => `${i.sku}:${i.quantity}`).join(", "))}</td>
              <td>${formatCurrency(po.estimatedValue)}</td>
              <td>${po.etaDays} дни</td>
              <td>${formatDateTime(po.createdAt)}</td>
              <td><div class="actions">
                ${po.status === "draft" && perms.manage ? `<button class="btn-secondary btn-sm" data-action="send" data-id="${escapeHtml(po.id)}">Изпрати</button>` : ""}
                ${po.status !== "received" && perms.manage ? `<button class="btn-ghost btn-sm" data-action="receive" data-id="${escapeHtml(po.id)}">Получено</button>` : ""}
                ${perms.del ? `<button class="btn-danger btn-sm" data-action="delete" data-id="${escapeHtml(po.id)}">Изтрий</button>` : ""}
              </div></td>
            </tr>`).join("") : `<tr><td colspan="8" class="empty">Няма заявки за дозареждане.</td></tr>`}
          </tbody>
        </table>
      </div>
    </section>
  `);

  wireEvents();
  setToolbarActions([{ label: "Преглед low-stock", className: "btn-secondary", onClick: () => (location.href = "inventory.html") }]);
}

function wireEvents() {
  const status = document.getElementById("restockStatus");
  document.getElementById("generateBtn").addEventListener("click", () => {
    if (!can("restock.generate")) return;
    const res = store.generateRestockOrders();
    status.className = `inline-status ${res.created ? "success" : "info"}`;
    status.textContent = res.created ? `Генерирани ${res.created} нови заявки.` : "Няма нови заявки за генериране.";
  });

  document.querySelector("tbody").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;
    const id = btn.dataset.id;
    if (btn.dataset.action === "send" && can("restock.manage")) store.updatePurchaseOrderStatus(id, "sent");
    if (btn.dataset.action === "receive" && can("restock.manage")) store.updatePurchaseOrderStatus(id, "received");
    if (btn.dataset.action === "delete" && can("restock.delete") && confirm(`Изтриване на заявка ${id}?`)) store.deletePurchaseOrder(id);
  });
}

if (appRoot) {
  store.subscribe(render);
  render();
}
