﻿import {
  clampInRange,
  clampNonNegative,
  clampNonNegativeInt,
  parseCsv,
  readFileText,
  round2,
  sameText,
  slugify,
  uid,
} from "./utils.js";
import { expandOrderWithProducts, optimizeOrder, parseOrderLines } from "./orderEngine.js";

const STORAGE_KEY = "warehouse-flow-suite-v1";
const ACTIVITY_LIMIT = 80;

const state = {
  products: [],
  suppliers: [],
  purchaseOrders: [],
  activities: [],
};

const listeners = new Set();
let initialized = false;

export const store = {
  init,
  subscribe,
  getState: () => structuredCloneSafe(state),
  save,
  seedSampleData,
  exportSnapshot,
  importFromFile,
  getDashboardMetrics,
  getLowStockProducts,
  getProducts,
  getSuppliers,
  getPurchaseOrders,
  getActivities,
  upsertProduct,
  deleteProduct,
  applyStockMovement,
  upsertSupplier,
  deleteSupplier,
  ensureSupplierExistsByName,
  generateRestockOrders,
  updatePurchaseOrderStatus,
  deletePurchaseOrder,
  processOrderRequest,
};

function init() {
  if (initialized) return;
  load();
  ensureSuppliersFromProducts();
  initialized = true;
}

function subscribe(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function emit() {
  for (const listener of listeners) listener(store.getState());
}

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw);
    state.products = Array.isArray(parsed.products) ? parsed.products.map(normalizeProduct).filter(Boolean) : [];
    state.suppliers = Array.isArray(parsed.suppliers) ? parsed.suppliers.map(normalizeSupplier).filter(Boolean) : [];
    state.purchaseOrders = Array.isArray(parsed.purchaseOrders)
      ? parsed.purchaseOrders.map(normalizePurchaseOrder).filter(Boolean)
      : [];
    state.activities = Array.isArray(parsed.activities) ? parsed.activities.slice(0, ACTIVITY_LIMIT) : [];
  } catch {
    state.products = [];
    state.suppliers = [];
    state.purchaseOrders = [];
    state.activities = [];
  }
}

function save() {
  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify({
      products: state.products,
      suppliers: state.suppliers,
      purchaseOrders: state.purchaseOrders,
      activities: state.activities.slice(0, ACTIVITY_LIMIT),
    })
  );
}

function structuredCloneSafe(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function addActivity(type, title, detail = "") {
  state.activities.unshift({ id: uid("act"), type, title, detail, at: new Date().toISOString() });
  state.activities = state.activities.slice(0, ACTIVITY_LIMIT);
}

function normalizeProduct(raw) {
  if (!raw || !raw.sku) return null;
  const sku = String(raw.sku).trim().toUpperCase();
  if (!sku) return null;
  return {
    sku,
    name: String(raw.name || "").trim(),
    category: String(raw.category || "").trim(),
    supplier: String(raw.supplier || "").trim(),
    zone: ["A", "B", "C", "D"].includes(String(raw.zone || "A").toUpperCase()) ? String(raw.zone || "A").toUpperCase() : "A",
    stock: clampNonNegativeInt(raw.stock),
    minStock: clampNonNegativeInt(raw.minStock),
    price: clampNonNegative(raw.price),
    leadTime: clampNonNegativeInt(raw.leadTime),
    supplierPriority: ["high", "medium", "low"].includes(raw.supplierPriority) ? raw.supplierPriority : "medium",
    description: String(raw.description || "").trim(),
    updatedAt: raw.updatedAt || new Date().toISOString(),
  };
}

function normalizeSupplier(raw) {
  if (!raw || !raw.name) return null;
  const name = String(raw.name).trim();
  if (!name) return null;
  return {
    id: String(raw.id || slugify(name) || uid("sup")),
    name,
    contactEmail: String(raw.contactEmail || "").trim(),
    phone: String(raw.phone || "").trim(),
    costMultiplier: clampInRange(raw.costMultiplier, 0.5, 10, 1),
    minOrderValue: clampNonNegative(raw.minOrderValue),
    defaultLeadTime: clampNonNegativeInt(raw.defaultLeadTime),
    notes: String(raw.notes || "").trim(),
    updatedAt: raw.updatedAt || new Date().toISOString(),
  };
}

function normalizePurchaseOrder(raw) {
  if (!raw || !raw.id || !raw.supplierName) return null;
  const statuses = ["draft", "sent", "received"];
  return {
    id: String(raw.id),
    supplierId: String(raw.supplierId || ""),
    supplierName: String(raw.supplierName),
    status: statuses.includes(raw.status) ? raw.status : "draft",
    items: Array.isArray(raw.items)
      ? raw.items
          .map((it) => ({
            sku: String(it.sku || "").trim().toUpperCase(),
            name: String(it.name || "").trim(),
            quantity: clampNonNegativeInt(it.quantity),
            unitPrice: clampNonNegative(it.unitPrice),
            estimatedLeadTime: clampNonNegativeInt(it.estimatedLeadTime),
          }))
          .filter((it) => it.sku && it.quantity > 0)
      : [],
    estimatedValue: clampNonNegative(raw.estimatedValue),
    etaDays: clampNonNegativeInt(raw.etaDays),
    createdAt: raw.createdAt || new Date().toISOString(),
    updatedAt: raw.updatedAt || new Date().toISOString(),
  };
}

function ensureSuppliersFromProducts() {
  let changed = false;
  for (const p of state.products) {
    if (!p.supplier) continue;
    if (!state.suppliers.some((s) => sameText(s.name, p.supplier))) {
      state.suppliers.push(
        normalizeSupplier({ name: p.supplier, defaultLeadTime: p.leadTime, notes: "Автоматично създаден от продуктов каталог" })
      );
      changed = true;
    }
  }
  if (changed) save();
}

function ensureSupplierExistsByName(name, extras = {}) {
  const clean = String(name || "").trim();
  if (!clean) return null;
  const existing = state.suppliers.find((s) => sameText(s.name, clean));
  if (existing) return existing;
  const supplier = normalizeSupplier({
    name: clean,
    defaultLeadTime: extras.defaultLeadTime || 0,
    notes: extras.notes || "Автоматично създаден",
  });
  state.suppliers.push(supplier);
  save();
  emit();
  return supplier;
}

function getProducts() {
  return [...state.products];
}

function getSuppliers() {
  return [...state.suppliers].sort((a, b) => a.name.localeCompare(b.name, "bg"));
}

function getPurchaseOrders() {
  return [...state.purchaseOrders].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function getActivities(limit = 30) {
  return state.activities.slice(0, limit);
}

function getLowStockProducts() {
  return state.products.filter((p) => p.stock <= p.minStock).sort((a, b) => (a.stock - a.minStock) - (b.stock - b.minStock));
}

function getDashboardMetrics() {
  const products = state.products;
  const totalUnits = products.reduce((sum, p) => sum + p.stock, 0);
  const totalValue = products.reduce((sum, p) => sum + p.stock * p.price, 0);
  const lowStockCount = products.filter((p) => p.stock <= p.minStock).length;
  const criticalCount = products.filter((p) => p.stock === 0).length;
  const openPOs = state.purchaseOrders.filter((po) => po.status !== "received").length;
  const avgLead = products.length ? products.reduce((sum, p) => sum + p.leadTime, 0) / products.length : 0;
  return {
    totalProducts: products.length,
    totalUnits,
    totalValue,
    lowStockCount,
    criticalCount,
    suppliersCount: state.suppliers.length,
    openPOs,
    avgLead,
    lowItems: getLowStockProducts().slice(0, 6),
  };
}

function upsertProduct(input) {
  init();
  const product = normalizeProduct({ ...input, updatedAt: new Date().toISOString() });
  if (!product || !product.sku || !product.name) throw new Error("SKU и име са задължителни.");
  const idx = state.products.findIndex((p) => p.sku === product.sku);
  const isUpdate = idx >= 0;
  if (isUpdate) state.products[idx] = { ...state.products[idx], ...product, updatedAt: new Date().toISOString() };
  else state.products.push(product);
  if (product.supplier) ensureSupplierExistsByName(product.supplier, { defaultLeadTime: product.leadTime });
  addActivity("product", `${isUpdate ? "Обновен" : "Добавен"} продукт ${product.sku}`, `${product.name} | ${product.stock} бр.`);
  save();
  emit();
  return product;
}

function deleteProduct(sku) {
  init();
  const target = state.products.find((p) => p.sku === String(sku).toUpperCase());
  if (!target) return false;
  state.products = state.products.filter((p) => p.sku !== target.sku);
  addActivity("product", `Изтрит продукт ${target.sku}`, target.name);
  save();
  emit();
  return true;
}

function applyStockMovement({ sku, type, quantity, note }) {
  init();
  const cleanSku = String(sku || "").trim().toUpperCase();
  const qty = clampNonNegativeInt(quantity);
  const product = state.products.find((p) => p.sku === cleanSku);
  if (!product) throw new Error(`Продукт с SKU ${cleanSku} не е намерен.`);
  if (qty < 1) throw new Error("Количеството трябва да е поне 1.");
  if (type === "out" && product.stock < qty) throw new Error(`Недостатъчна наличност: ${product.stock} бр.`);
  product.stock += type === "in" ? qty : -qty;
  product.updatedAt = new Date().toISOString();
  addActivity("movement", `${type === "in" ? "Входящо" : "Изходящо"} движение ${product.sku}`, `${type === "in" ? "+" : "-"}${qty}${note ? ` | ${note}` : ""}`);
  save();
  emit();
  return product;
}

function upsertSupplier(input) {
  init();
  const supplier = normalizeSupplier({ ...input, updatedAt: new Date().toISOString() });
  if (!supplier) throw new Error("Името на доставчика е задължително.");
  const idx = state.suppliers.findIndex((s) => s.id === supplier.id || sameText(s.name, supplier.name));
  const isUpdate = idx >= 0;
  if (isUpdate) state.suppliers[idx] = { ...state.suppliers[idx], ...supplier, updatedAt: new Date().toISOString() };
  else state.suppliers.push(supplier);
  addActivity("supplier", `${isUpdate ? "Обновен" : "Добавен"} доставчик`, supplier.name);
  save();
  emit();
  return supplier;
}

function deleteSupplier(id) {
  init();
  const supplier = state.suppliers.find((s) => s.id === id);
  if (!supplier) return false;
  state.suppliers = state.suppliers.filter((s) => s.id !== id);
  addActivity("supplier", "Изтрит доставчик", supplier.name);
  save();
  emit();
  return true;
}

async function importFromFile(file, { target, mode }) {
  init();
  const text = await readFileText(file);
  let rows;
  const lower = file.name.toLowerCase();
  if (lower.endsWith(".json")) rows = parseJsonRows(text, target);
  else if (lower.endsWith(".csv")) rows = parseCsvRows(text, target);
  else throw new Error("Поддържани формати: .json, .csv");
  const result = applyImportedRows(rows, { target, mode });
  addActivity("import", `Импорт ${target}`, `${result.created} нови / ${result.updated} обновени / ${result.skipped} пропуснати`);
  save();
  emit();
  return result;
}

function parseJsonRows(text, target) {
  const parsed = JSON.parse(text);
  if (Array.isArray(parsed)) return parsed;
  if (parsed && Array.isArray(parsed[target])) return parsed[target];
  throw new Error("JSON трябва да е масив или да има ключ products/suppliers.");
}

function parseCsvRows(text, target) {
  const rows = parseCsv(text);
  if (target === "products") return rows;
  if (target === "suppliers") return rows;
  throw new Error("Непознат import target.");
}

function applyImportedRows(rows, { target, mode }) {
  if (!Array.isArray(rows)) throw new Error("Невалидни данни за импорт.");
  const summary = { created: 0, updated: 0, skipped: 0 };
  if (target === "products") {
    if (mode === "replace") state.products = [];
    for (const raw of rows) {
      const p = normalizeProduct(raw);
      if (!p) {
        summary.skipped += 1;
        continue;
      }
      const idx = state.products.findIndex((x) => x.sku === p.sku);
      if (idx >= 0) {
        state.products[idx] = { ...state.products[idx], ...p, updatedAt: new Date().toISOString() };
        summary.updated += 1;
      } else {
        state.products.push(p);
        summary.created += 1;
      }
      if (p.supplier) ensureSupplierExistsByName(p.supplier, { defaultLeadTime: p.leadTime });
    }
    return summary;
  }
  if (target === "suppliers") {
    if (mode === "replace") state.suppliers = [];
    for (const raw of rows) {
      const s = normalizeSupplier(raw);
      if (!s) {
        summary.skipped += 1;
        continue;
      }
      const idx = state.suppliers.findIndex((x) => x.id === s.id || sameText(x.name, s.name));
      if (idx >= 0) {
        state.suppliers[idx] = { ...state.suppliers[idx], ...s, updatedAt: new Date().toISOString() };
        summary.updated += 1;
      } else {
        state.suppliers.push(s);
        summary.created += 1;
      }
    }
    return summary;
  }
  throw new Error("Непознат import target.");
}

function exportSnapshot() {
  return {
    exportedAt: new Date().toISOString(),
    products: state.products,
    suppliers: state.suppliers,
    purchaseOrders: state.purchaseOrders,
    activities: state.activities,
  };
}

function generateRestockOrders({ supplierId = null } = {}) {
  init();
  const low = getLowStockProducts();
  const groups = new Map();
  let created = 0;

  for (const product of low) {
    const supplier = findOrAutoSupplier(product);
    if (!supplier) continue;
    if (supplierId && supplier.id !== supplierId) continue;
    const existsOpen = state.purchaseOrders.some((po) => (po.status === "draft" || po.status === "sent") && (po.supplierId === supplier.id || sameText(po.supplierName, supplier.name)) && po.items.some((it) => it.sku === product.sku));
    if (existsOpen) continue;
    const qty = computeReorderQty(product, supplier);
    if (!qty) continue;
    if (!groups.has(supplier.id)) groups.set(supplier.id, { supplier, items: [] });
    groups.get(supplier.id).items.push({
      sku: product.sku,
      name: product.name,
      quantity: qty,
      unitPrice: round2(product.price * (supplier.costMultiplier || 1)),
      estimatedLeadTime: Math.max(product.leadTime, supplier.defaultLeadTime || 0),
    });
  }

  for (const { supplier, items } of groups.values()) {
    const estimatedValueRaw = round2(items.reduce((sum, it) => sum + it.quantity * it.unitPrice, 0));
    const po = normalizePurchaseOrder({
      id: `PO-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
      supplierId: supplier.id,
      supplierName: supplier.name,
      status: "draft",
      items,
      estimatedValue: Math.max(estimatedValueRaw, supplier.minOrderValue || 0),
      etaDays: Math.max(0, ...items.map((i) => i.estimatedLeadTime)),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    state.purchaseOrders.unshift(po);
    created += 1;
    addActivity("restock", `Генерирана заявка ${po.id}`, `${po.supplierName} | ${po.items.length} позиции`);
  }

  if (created) {
    state.purchaseOrders = state.purchaseOrders.slice(0, 120);
    save();
    emit();
  }
  return { created, orders: getPurchaseOrders() };
}

function findOrAutoSupplier(product) {
  if (!product.supplier) return ensureSupplierExistsByName("Unknown Supplier");
  return state.suppliers.find((s) => sameText(s.name, product.supplier)) || ensureSupplierExistsByName(product.supplier, { defaultLeadTime: product.leadTime });
}

function computeReorderQty(product, supplier) {
  const target = Math.max(product.minStock * 2, product.minStock + 1);
  let qty = Math.max(1, target - product.stock);
  if (product.stock === 0) qty += Math.max(1, product.minStock);
  if ((supplier.defaultLeadTime || 0) >= 7 || product.leadTime >= 7) qty += Math.max(1, Math.ceil(product.minStock * 0.5));
  return Math.max(1, Math.round(qty));
}

function updatePurchaseOrderStatus(id, status) {
  init();
  const po = state.purchaseOrders.find((x) => x.id === id);
  if (!po) throw new Error("Заявката не е намерена.");
  if (!["draft", "sent", "received"].includes(status)) throw new Error("Невалиден статус.");
  if (status === "received" && po.status !== "received") {
    for (const item of po.items) {
      const product = state.products.find((p) => p.sku === item.sku);
      if (product) {
        product.stock += item.quantity;
        product.updatedAt = new Date().toISOString();
      }
    }
  }
  po.status = status;
  po.updatedAt = new Date().toISOString();
  addActivity("restock", `Обновена заявка ${po.id}`, `Статус: ${status}`);
  save();
  emit();
  return po;
}

function deletePurchaseOrder(id) {
  init();
  const po = state.purchaseOrders.find((x) => x.id === id);
  if (!po) return false;
  state.purchaseOrders = state.purchaseOrders.filter((x) => x.id !== id);
  addActivity("restock", `Изтрита заявка ${po.id}`, po.supplierName);
  save();
  emit();
  return true;
}

function processOrderRequest({ text, mode, laborRate, zoneSwitchCost, commit }) {
  init();
  const parsed = parseOrderLines(text);
  if (parsed.errors.length) return { ok: false, title: "Грешка при парсване", errors: parsed.errors };
  if (!parsed.lines.length) return { ok: false, title: "Няма редове", errors: ["Въведи поне един ред SKU:количество"] };

  const expanded = expandOrderWithProducts(parsed.lines, state.products);
  if (expanded.errors.length) return { ok: false, title: "Невалидна поръчка", errors: expanded.errors };

  const optimized = optimizeOrder(expanded.lines, { mode, laborRate, zoneSwitchCost });
  if (!optimized.ok) return { ok: false, title: "Грешка при оптимизация", errors: optimized.errors };

  const lowAfter = [];
  if (commit) {
    for (const step of optimized.sequence) {
      const product = state.products.find((p) => p.sku === step.sku);
      product.stock -= step.quantity;
      product.updatedAt = new Date().toISOString();
      if (product.stock <= product.minStock) lowAfter.push(product);
    }
    addActivity("order", `Обработена поръчка (${optimized.sequence.length} позиции)`, `Режим: ${mode} | Спестено ${round2(optimized.savings.minutes)} мин`);
    save();
    emit();
    if (lowAfter.length) generateRestockOrders();
  } else {
    for (const step of optimized.sequence) {
      const projected = step.product.stock - step.quantity;
      if (projected <= step.product.minStock) lowAfter.push({ ...step.product, stock: projected });
    }
  }

  return { ok: true, commit, optimized, lowAfter };
}

function seedSampleData() {
  state.products = [
    { sku: "SKU-001", name: "Индустриален сензор X12", category: "Сензори", supplier: "TechSupply BG", zone: "A", stock: 24, minStock: 10, price: 48.5, leadTime: 3, supplierPriority: "high", description: "Сензор за температура и вибрации" },
    { sku: "SKU-002", name: "Контролен модул CM-8", category: "Контролери", supplier: "FactoryCore", zone: "B", stock: 12, minStock: 8, price: 179, leadTime: 5, supplierPriority: "medium", description: "PLC модул" },
    { sku: "SKU-003", name: "Линейно задвижване L-90", category: "Механика", supplier: "Motion Parts", zone: "D", stock: 7, minStock: 6, price: 320, leadTime: 9, supplierPriority: "low", description: "Задвижване за ос" },
    { sku: "SKU-004", name: "Кабелен комплект PRO-24", category: "Кабели", supplier: "Electra Trade", zone: "C", stock: 68, minStock: 20, price: 12.8, leadTime: 2, supplierPriority: "high", description: "Кабели и конектори" },
    { sku: "SKU-005", name: "Хидравличен клапан HV-5", category: "Хидравлика", supplier: "Fluid Systems", zone: "D", stock: 4, minStock: 5, price: 265, leadTime: 11, supplierPriority: "low", description: "Клапан високо налягане" },
    { sku: "SKU-006", name: "Ролков лагер RL-220", category: "Механика", supplier: "Motion Parts", zone: "B", stock: 35, minStock: 15, price: 34, leadTime: 4, supplierPriority: "medium", description: "Лагер" },
  ].map(normalizeProduct);
  state.suppliers = [
    { name: "TechSupply BG", contactEmail: "ops@techsupply.bg", phone: "+359888000001", costMultiplier: 1, minOrderValue: 100, defaultLeadTime: 3, notes: "Основен доставчик" },
    { name: "FactoryCore", contactEmail: "sales@factorycore.eu", phone: "+359888000002", costMultiplier: 1.05, minOrderValue: 300, defaultLeadTime: 5, notes: "Контролери" },
    { name: "Motion Parts", contactEmail: "orders@motionparts.com", phone: "+359888000003", costMultiplier: 1.02, minOrderValue: 250, defaultLeadTime: 7, notes: "Механика" },
    { name: "Electra Trade", contactEmail: "supply@electra.bg", phone: "+359888000004", costMultiplier: 0.98, minOrderValue: 80, defaultLeadTime: 2, notes: "Кабели" },
    { name: "Fluid Systems", contactEmail: "support@fluidsystems.com", phone: "+359888000005", costMultiplier: 1.1, minOrderValue: 500, defaultLeadTime: 10, notes: "Хидравлика" },
  ].map(normalizeSupplier);
  state.purchaseOrders = [];
  addActivity("system", "Заредени примерни данни", `Продукти: ${state.products.length}, доставчици: ${state.suppliers.length}`);
  save();
  emit();
}
