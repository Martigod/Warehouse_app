﻿import { setupAppShell, mount, setToolbarActions } from "./layout.js";
import { store } from "./store.js";
import { escapeHtml, formatCurrency } from "./utils.js";
import { can, canAccessPage, getSession } from "./auth.js";

const appRoot = setupAppShell({
  page: "orders",
  title: "Поръчки",
  subtitle: "Оптимизация на picking маршрута и автоматична реакция при риск от недостиг.",
});

let lastResult = null;

function render() {
  const lowItems = store.getLowStockProducts().slice(0, 8);
  const canSimulate = can("orders.simulate");
  const canProcess = can("orders.process");
  const showRestockShortcut = canAccessPage("restock", getSession());
  mount(`
    <div class="two-col">
      <section class="panel">
        <div class="panel-header"><div><h3>Оптимизиране на поръчка</h3><p>Формат: SKU:количество (по един ред)</p></div></div>
        <form id="orderForm" class="stack">
          <label>Поръчка<textarea name="orderLines" rows="10" placeholder="SKU-001:4&#10;SKU-003:2"></textarea></label>
          <div class="grid cols-3">
            <label>Режим<select name="mode"><option value="balanced">Balanced</option><option value="fast">Fast</option><option value="cost">Cost Saver</option></select></label>
            <label>Разход/минута (лв)<input type="number" step="0.1" min="0" name="laborRate" value="1.4" /></label>
            <label>Цена смяна зона (лв)<input type="number" step="0.1" min="0" name="zoneSwitchCost" value="3.5" /></label>
          </div>
          <div class="actions">
            <button type="submit" class="btn-primary" ${canProcess ? "" : "disabled"}>Оптимизирай и обработи</button>
            <button type="button" id="simulateBtn" class="btn-ghost" ${canSimulate ? "" : "disabled"}>Симулация</button>
            <span id="orderStatus" class="inline-status"></span>
          </div>
        </form>
        <div id="orderResult" class="order-result"></div>
      </section>

      <section class="panel">
        <div class="panel-header"><div><h3>Текущ риск от недостиг</h3><p>Продукти под минимален праг</p></div></div>
        ${lowItems.length ? `<ul class="list">${lowItems.map((p) => `<li><span class="mono">${escapeHtml(p.sku)}</span> - ${escapeHtml(p.name)} (${p.stock}/${p.minStock})</li>`).join("")}</ul>` : `<div class="empty">Няма продукти под минималния праг.</div>`}
        <p class="note" style="margin-top:10px;">След обработка на поръчка системата може да генерира заявки за дозареждане автоматично.</p>
      </section>
    </div>
  `);

  wireEvents();
  renderLastResult();
  setToolbarActions(showRestockShortcut ? [{ label: "Отвори дозареждане", className: "btn-secondary", onClick: () => (location.href = "restock.html") }] : []);
}

function wireEvents() {
  const form = document.getElementById("orderForm");
  const status = document.getElementById("orderStatus");

  const run = (commit) => {
    if (commit && !can("orders.process")) {
      status.className = "inline-status error";
      status.textContent = "Нямаш права да обработваш поръчки.";
      return;
    }
    if (!commit && !can("orders.simulate")) {
      status.className = "inline-status error";
      status.textContent = "Нямаш права за симулация.";
      return;
    }
    const fd = new FormData(form);
    const res = store.processOrderRequest({
      text: fd.get("orderLines"),
      mode: fd.get("mode"),
      laborRate: fd.get("laborRate"),
      zoneSwitchCost: fd.get("zoneSwitchCost"),
      commit,
    });
    lastResult = res;
    status.className = `inline-status ${res.ok ? "success" : "error"}`;
    status.textContent = res.ok ? (commit ? "Поръчката е обработена." : "Симулацията е готова.") : (res.title || "Грешка");
    renderLastResult();
  };

  form.addEventListener("submit", (e) => { e.preventDefault(); run(true); });
  document.getElementById("simulateBtn").addEventListener("click", () => run(false));
}

function renderLastResult() {
  const box = document.getElementById("orderResult");
  if (!box) return;
  if (!lastResult) {
    box.innerHTML = '<div class="note">Все още няма обработена/симулирана поръчка.</div>';
    return;
  }
  if (!lastResult.ok) {
    box.innerHTML = `<div class="panel" style="padding:10px;"><strong>${escapeHtml(lastResult.title || "Грешка")}</strong><ul class="list">${(lastResult.errors || []).map((e) => `<li>${escapeHtml(e)}</li>`).join("")}</ul></div>`;
    return;
  }

  const r = lastResult.optimized;
  const m = r.metrics;
  const b = r.baseline;
  box.innerHTML = `
    <section class="panel" style="padding:10px;">
      <div class="actions" style="margin-bottom:8px;"><span class="pill ${lastResult.commit ? "ok" : "draft"}">${lastResult.commit ? "Обработена поръчка" : "Симулация"}</span></div>
      <div class="stats" style="grid-template-columns:repeat(4,minmax(0,1fr));">
        <article class="stat-card"><div class="k">Време</div><div class="v">${m.totalMinutes}</div><div class="h">мин</div></article>
        <article class="stat-card"><div class="k">Оперативен разход</div><div class="v">${formatCurrency(m.totalOperationalCost)}</div><div class="h">labor + zone switches</div></article>
        <article class="stat-card"><div class="k">Смени зона</div><div class="v">${m.zoneSwitches}</div><div class="h">Оптимизиран маршрут</div></article>
        <article class="stat-card"><div class="k">Спестено</div><div class="v">${r.savings.minutes.toFixed(2)}м</div><div class="h">${formatCurrency(r.savings.cost)}</div></article>
      </div>
      <p class="note" style="margin-top:8px;">Стратегия: <strong>${escapeHtml(r.selectedStrategy)}</strong> | Базов ред: ${b.totalMinutes} мин / ${formatCurrency(b.totalOperationalCost)}</p>
      <ol class="list">${r.sequenceSummary.map((x) => `<li>Зона ${x.zone} • <span class="mono">${escapeHtml(x.sku)}</span> • ${escapeHtml(x.name)} • ${x.quantity} бр.</li>`).join("")}</ol>
      ${lastResult.lowAfter?.length ? `<p class="note">След изпълнението/симулацията ще има ${lastResult.lowAfter.length} SKU под минималния праг.</p>` : ""}
    </section>`;
}

if (appRoot) {
  store.subscribe(render);
  render();
}
