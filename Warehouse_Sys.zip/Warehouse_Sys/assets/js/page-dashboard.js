﻿import { setupAppShell, mount } from "./layout.js";
import { store } from "./store.js";
import { escapeHtml, formatCurrency, formatDateTime } from "./utils.js";

const appRoot = setupAppShell({
  page: "dashboard",
  title: "Dashboard",
  subtitle: "Обобщена картина на склада, рискове от недостиг и последни действия.",
});

function render() {
  const s = store.getDashboardMetrics();
  const activities = store.getActivities(12);
  mount(`
    <section class="panel">
      <div class="stats">
        <article class="stat-card"><div class="k">Продукти</div><div class="v">${s.totalProducts}</div><div class="h">Уникални SKU</div></article>
        <article class="stat-card"><div class="k">Стойност склад</div><div class="v">${formatCurrency(s.totalValue)}</div><div class="h">${s.totalUnits} бр. общо</div></article>
        <article class="stat-card"><div class="k">Ниска наличност</div><div class="v">${s.lowStockCount}</div><div class="h">${s.criticalCount} изчерпани</div></article>
        <article class="stat-card"><div class="k">Доставчици / Open PO</div><div class="v">${s.suppliersCount} / ${s.openPOs}</div><div class="h">Lead: ${s.avgLead.toFixed(1)} дни</div></article>
      </div>
    </section>

    <div class="two-col">
      <section class="panel">
        <div class="panel-header"><div><h3>Аларми и рискове</h3><p>Продукти под минимален праг</p></div></div>
        <div class="alerts">
          ${s.lowItems.length ? `<div class="alert warn"><strong>Нужни действия:</strong> ${s.lowItems.map((p) => `${escapeHtml(p.sku)} (${p.stock}/${p.minStock})`).join(", ")}</div>` : `<div class="alert ok">Няма продукти под минимален праг.</div>`}
          <div class="alert">Среден lead time: <strong>${s.avgLead.toFixed(1)} дни</strong></div>
          <div class="alert">Отворени заявки за дозареждане: <strong>${s.openPOs}</strong></div>
        </div>
      </section>

      <section class="panel">
        <div class="panel-header"><div><h3>Последни действия</h3><p>История на операции в системата</p></div></div>
        <div class="activity">
          ${activities.length ? activities.map((a) => `<div class="activity-item"><div><strong>${escapeHtml(a.title)}</strong></div><div>${escapeHtml(a.detail || "-")}</div><div class="meta">${escapeHtml(a.type)} • ${formatDateTime(a.at)}</div></div>`).join("") : `<div class="empty">Все още няма действия.</div>`}
        </div>
      </section>
    </div>

    <section class="panel">
      <div class="panel-header"><div><h3>Топ продукти с риск</h3><p>Бърза видимост върху критични SKU</p></div></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>SKU</th><th>Име</th><th>Наличност</th><th>Мин. праг</th><th>Доставчик</th><th>Lead</th></tr></thead>
          <tbody>
            ${s.lowItems.length ? s.lowItems.map((p) => `<tr><td class="mono">${escapeHtml(p.sku)}</td><td>${escapeHtml(p.name)}</td><td><span class="pill ${p.stock === 0 ? "critical" : "low"}">${p.stock}</span></td><td>${p.minStock}</td><td>${escapeHtml(p.supplier || "-")}</td><td>${p.leadTime} дни</td></tr>`).join("") : `<tr><td colspan="6" class="empty">Няма рискови продукти.</td></tr>`}
          </tbody>
        </table>
      </div>
    </section>
  `);
}

if (appRoot) {
  store.subscribe(render);
  render();
}
